import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { NgxSpinnerService } from 'ngx-spinner';
import { ToastrService } from 'ngx-toastr';
import { DataService } from 'src/app/service/data.service';

@Component({
  selector: 'app-add-objective',
  templateUrl: './add-objective.component.html',
  styleUrls: ['./add-objective.component.scss']
})
export class AddObjectiveComponent implements OnInit {
  @Input('myInputVal') myInputVal: string;
  @Output('myOutputVal') myOutputVal = new EventEmitter();
  objecativeForm: FormGroup;
  submitted = false;
  employeeList: any;
  errMessage: any;
  close = true;
  constructor(private dataService: DataService, private toaster: ToastrService, private spinner: NgxSpinnerService, private fb: FormBuilder) {
    this.dataService.employeeList().subscribe(data => {
      if (data.status == 200) {
        this.employeeList = data.data
      }
      if (data.status == 404) {
        this.errMessage = "No Record Found!";
      }
      if (data.status == 500) {
        this.errMessage = "Unable To Process";
      }
    })
    //objective form
    this.objecativeForm = this.fb.group({
      name: ['', [Validators.required]],
      status: ['', [Validators.required]],
      startDate: ['', [Validators.required]],
      endDate: ['', [Validators.required]],
      description: ['', [Validators.required]],
      goalId: [''],
      assignBy: [''],
      assignTo: ['']
    })
    this.dataService.stringSubject.subscribe(
      data => {
        this.myInputVal = data;
        console.log(this.myInputVal)
        //emitting value to parent component using event emitter
        // this.myOutputVal.emit(this.myInputVal + ' from child.');
      }
    );
  }

  ngOnInit(): void {
  }
  //create  objecative
  onSubmit() {
    this.submitted = false;
    // this.close = false;
    if (this.objecativeForm.invalid) {
      console.table(this.objecativeForm.value);
      return
    }
    if (this.objecativeForm.valid) {
      console.table(this.objecativeForm.value);
    }
    this.dataService.createObjective({
      name: this.objecativeForm.value.name,
      status: this.objecativeForm.value.status,
      startDate: this.objecativeForm.value.startDate,
      endDate: this.objecativeForm.value.endDate,
      description: this.objecativeForm.value.description,
      goalsId: this.myInputVal
    }).subscribe(data => {
      if (data.status == 200) {
        this.toaster.success('Objecative Create Successfully');
        this.objecativeForm.reset();
        this.submitted = false;
      }
      if (data.status == 208) {
        this.toaster.error('Objecative Already Exits');
      }
      if (data.status == 404) {
        this.toaster.error('Req Body Is Empty');
      }
      if (data.status == 500) {
        this.toaster.error('Unable To Process');
      }
    })
  }
  updateObjective(id: any) {
    this.submitted = false;
    // this.close = false;
    if (this.objecativeForm.invalid) {
      console.table(this.objecativeForm.value);
      return
    }
    if (this.objecativeForm.valid) {
      console.table(this.objecativeForm.value);
    }
    this.dataService.updateObjective(id, {
      name: this.objecativeForm.value.name,
      status: this.objecativeForm.value.status,
      startDate: this.objecativeForm.value.startDate,
      endDate: this.objecativeForm.value.endDate,
      description: this.objecativeForm.value.description,
      goalsId: 1,
    }).subscribe(data => {
      if (data.status == 200) {
        this.toaster.success('Update Successfully');
      }
      if (data.status == 404) {
        this.toaster.error('No Content');
      }
      if (data.status == 500) {
        this.toaster.error('Unable To Process');
      }
    })
  }
  get f() {
    return this.objecativeForm.controls;
  }
}
