import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddKeyActivityComponent } from './add-key-activity.component';

describe('AddKeyActivityComponent', () => {
  let component: AddKeyActivityComponent;
  let fixture: ComponentFixture<AddKeyActivityComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddKeyActivityComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AddKeyActivityComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
