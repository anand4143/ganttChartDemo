import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { DataService } from 'src/app/service/data.service';

@Component({
  selector: 'app-add-key-activity',
  templateUrl: './add-key-activity.component.html',
  styleUrls: ['./add-key-activity.component.scss']
})
export class AddKeyActivityComponent implements OnInit {
  activityForm: FormGroup;
  submitted = false;
  employeeList: any;
  errMessage: any;
  constructor(private dataService: DataService, private fb: FormBuilder, private toaster: ToastrService) {
    //activity form
    this.activityForm = this.fb.group({
      name: ['', [Validators.required]],
      status: ['', [Validators.required]],
      startDate: ['', [Validators.required]],
      endDate: ['', [Validators.required]],
      description: ['', [Validators.required]],
      goalsId: [''],
      objectiveId: [''],
      strategyId: [''],
      tacticsId: [''],
      assignBy: [''],
      assignTo: ['']
    })
    this.dataService.employeeList().subscribe(data => {
      if (data.status == 200) {
        this.employeeList = data.data
      }
      if (data.status == 404) {
        this.errMessage = "No Record Found!";
      }
      if (data.status == 500) {
        this.errMessage = "Unable To Process";
      }
    })
  }

  ngOnInit(): void {
  }
  ///
  updateActivity(id: any) {
    this.dataService.updateActivity(id, {}).subscribe(data => {
      if (data.status == 200) {
        this.toaster.success('Update Successfully');
      }
      if (data.status == 404) {
        this.toaster.error('No Content');
      }
      if (data.status == 500) {
        this.toaster.error('Unable To Process');
      }
    })
  }
  onSubmit() {
    this.submitted = false;
    if (this.activityForm.invalid) {
      console.table(this.activityForm.value);
      return
    }
    if (this.activityForm.valid) {
      console.table(this.activityForm.value);
    }
    this.dataService.createActivity({
      name: this.activityForm.value.name,
      status: this.activityForm.value.status,
      startDate: this.activityForm.value.startDate,
      endDate: this.activityForm.value.endDate,
      goalsId: this.activityForm.value.goalsId,
      objectiveId: "",
      strategyId: "",
      tacticsId: "",
      assignBy: "",
    }).subscribe(data => {
      if (data.status == 200) {
        this.toaster.success('Tactics Create Successfully');
      }
      if (data.status == 208) {
        this.toaster.error('Objecative Already Exits');
      }
      if (data.status == 404) {
        this.toaster.error('Req Body Is Empty');
      }
      if (data.status == 500) {
        this.toaster.error('Unable To Process');
      }
    })
  }
  get f() {
    return this.activityForm.controls;
  }
}
