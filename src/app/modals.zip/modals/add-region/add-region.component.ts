import { Component, Input, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { DataService } from 'src/app/service/data.service';

@Component({
  selector: 'app-add-region',
  templateUrl: './add-region.component.html',
  styleUrls: ['./add-region.component.scss']
})
export class AddRegionComponent implements OnInit {
  _name: string; @Input('idxx')
  get name(): string { return this._name; }

  id: any;
  submitted = false;
  regionForm: FormGroup;
  buttonText = 'Create';
  headingText = 'Add User';
  status = false;
  constructor(private dataService: DataService, private fb: FormBuilder, private toaster: ToastrService) {
    this.regionForm = this.fb.group({
      name: ['', [Validators.required]],
    });
  }

  ngOnInit(): void {
  }
  onSubmit() {
    if (parseInt(this.id) > 0) {
      this.update();
    }
    else {
      this.submitted = true;
      if (this.regionForm.invalid) {
        console.table(this.regionForm.value);
        return
      }
      if (this.regionForm.valid) {
        console.table(this.regionForm.value);
      }
      this.dataService.addRegion({
        name: this.regionForm.value.name,
        status: 1,
      }).subscribe(data => {
        if (data.status == 200) {
          this.toaster.success('Region Add Successfully');
          this.regionForm.patchValue({
            name: "",
          });
          this.submitted = false;
        }
        if (data.status == 208) {
          this.toaster.error('Region Already Exits');
        }
        if (data.status == 204) {
          this.toaster.error('No Content');
        }
        if (data.status == 500) {
          this.toaster.error('Unable To Process');
        }
      })
    }

  }
  update() {
    this.submitted = true;
    if (this.regionForm.invalid) {
      console.table(this.regionForm.value);
      return
    }
    if (this.regionForm.valid) {
      console.table(this.regionForm.value);
    }
    this.dataService.updateRegion(this.id, {
      name: this.regionForm.value.name,
      status: 1,
    }).subscribe(data => {
      if (data.status == 200) {
        this.toaster.success('Update Successfully');
      }
      if (data.status == 208) {
        this.toaster.error('Region Already Exits');
      }
      if (data.status == 204) {
        this.toaster.error('No Content');
      }
      if (data.status == 500) {
        this.toaster.error('Unable To Process');
      }
    })


  }
  get f() {
    return this.regionForm.controls;
  }
  set name(name: string) {
    console.log(name)
    this._name = name || '<id not found>';
    if (this._name == 'add') {
      console.log(name)
      this.headingText = "Add New Region";
      this.buttonText = "Create";
      this.status = false
      console.log(this.status)
      this.regionForm.patchValue({
        name: "",
      });
      this.regionForm.reset();
    }
    else {
      this.status = true
      this.id = name;
      if (parseInt(this.id) > 0) {
        this.buttonText = 'Update';
        this.headingText = "Update Region"
        this.dataService.getRegionById(this.id).subscribe(data => {
          console.log(data)
          if (data.status == 200) {
            this.regionForm.patchValue({
              name: "" + data.data.name,
            })
          }
          if (data.status == 304) {
            this.toaster.error('Not Modify');
          }
          if (data.status == 500) {
            this.toaster.error('Unable To Process');
          }
        })
      }
    }
  }
}
