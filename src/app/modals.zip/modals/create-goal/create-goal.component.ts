import { Component, Input, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { DataService } from 'src/app/service/data.service';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-create-goal',
  templateUrl: './create-goal.component.html',
  styleUrls: ['./create-goal.component.scss']
})
export class CreateGoalComponent implements OnInit {
  _id: string; @Input('data')
  get id(): string { return this._id; }
  set id(id: string) {
    this._id = id || '<id not found>';
    console.log(this._id)
  }
  employeeList: any;
  projetctId: any;
  goalRecord: any;
  errMessage: any;
  goalFrom: FormGroup;
  submitted = false;
  private imgUrl = environment.apiUrl;
  constructor(private dataService: DataService, private fb: FormBuilder, private toaster: ToastrService) {
    this.goalFrom = this.fb.group({
      name: ['', [Validators.required]],
      status: ['', [Validators.required]],
      startDate: ['', [Validators.required]],
      endDate: ['', [Validators.required]],
      description: ['', [Validators.required]],
      assignTo: [''],
    })
    this.dataService.employeeList().subscribe(data => {
      if (data.status == 200) {
        this.employeeList = data.data
        this.employeeList.forEach(element => {
          element.profilePic = this.imgUrl + element.profilePic
        });
      }
      if (data.status == 404) {
        this.errMessage = "No Record Found!";
      }
      if (data.status == 500) {
        this.errMessage = "Unable To Process";
      }
    })
    this.dataService.getGoals().subscribe(data => {
      if (data.status == 200) {
        this.goalRecord = data.data;
        console.log(this.goalRecord);
      }
      if (data.status == 404) {
        // this.errMessage = "No Record Found!";
      }
      if (data.status == 500) {
        this.errMessage = "Unable To Process";
      }
    })
  }

  ngOnInit(): void {
    this.goalFrom.patchValue({
      name: "",
      status: "",
      startDate: "",
      endDate: "",
      description: "",
      assignTo: ""
    })
  }
  get f() { return this.goalFrom.controls; }
  onSubmit() {
    this.submitted = true;
    if (this.goalFrom.invalid) {
      console.table(this.goalFrom.value);
      return
    }
    if (this.goalFrom.valid) {
      console.table(this.goalFrom.value);
    }
    this.dataService.createGoals({
      projectId: this.id,
      name: this.goalFrom.value.name,
      status: this.goalFrom.value.status,
      startDate: this.goalFrom.value.startDate,
      endDate: this.goalFrom.value.endDate,
      description: this.goalFrom.value.description,
      assignTo: this.goalFrom.value.assignTo
    }).subscribe(data => {
      if (data.status == 200) {
        this.toaster.success('Goal Create Successfully');
      }
      if (data.status == 404) {
        this.toaster.error('No Content');
      }
      if (data.status == 208) {
        this.toaster.error('Goal Already Exits');
      }
      if (data.status == 500) {
        this.toaster.error('Unable To Process');
      }
    })
  }
  assignEvent(e: any, value: any) {
    console.log(this.goalFrom.value.assignTo, value)
    this.goalFrom.value.assignTo
  }
  ////////////////////update 
  updateGoal(id: any) {
    this.dataService.updateGoal(id, {}).subscribe(data => {
      if (data.status == 200) {
        this.toaster.success('Update Successfully');
      }
      if (data.status == 404) {
        this.toaster.error('No Content');
      }
      if (data.status == 500) {
        this.toaster.error('Unable To Process');
      }
    })
  }
}
