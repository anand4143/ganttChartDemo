import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { Subject } from 'rxjs';
import { DataService } from 'src/app/service/data.service';
import { MustMatch } from 'src/app/service/mustMatchValidtor';

@Component({
  selector: 'app-add-user',
  templateUrl: './add-user.component.html',
  styleUrls: ['./add-user.component.scss']
})
export class AddUserComponent implements OnInit {
  @Output('myOutputVal') myOutputVal = new EventEmitter();
  _name: string; @Input('movie')
  get name(): string { return this._name; }
  emplyeeForm: FormGroup;
  id: any;
  button = "save";
  editMode = 0;
  submitted = false;
  status: boolean = false;
  closeResult: string;
  selectedFiles?: FileList;
  currentFile?: File;
  companyId: any;
  uploadList: any;
  regionRecord: any;
  roleRecord: any;
  buttonText = 'Create';
  headingText = 'Add User';
  constructor(private router: Router,
    private dataService: DataService, private fb: FormBuilder, private toastr: ToastrService, private routes: ActivatedRoute) {
    this.routes.params.subscribe(params => {
      this.companyId = params['id'];
    });
    this.emplyeeForm = this.fb.group({
      name: ['', [Validators.required, Validators.pattern('[a-zA-Z ]*')]],
      userName: ['', [Validators.required]],
      password: ['', [Validators.required, Validators.minLength(6)]],
      email: ['', [Validators.required, Validators.email]],
      mobileNo: ['', [Validators.required, Validators.minLength(10), Validators.maxLength(11), Validators.pattern("^[0-9]*$")]],
      roleId: ['', [Validators.required]],
      companyId: [''],
      employeeCode: ['', [Validators.required]],
      regionId: ['', [Validators.required]],
      confirmPassword: ['', [Validators.required]],
    }, {
      validator: MustMatch("password", "confirmPassword")
    })
    this.dataService.getRegion().subscribe(data => {
      if (data.status == 200) {
        this.regionRecord = data.data
      }
      if (data.status == 204) {
        // this.toastr.error('No Record Found!');
      }
      if (data.status == 500) {
        this.toastr.error('Unable To Process');
      }
    })
    this.getRole();
    this.id = localStorage.getItem('id');

    console.log('name', this._name)

  }

  ngOnInit(): void {
    console.log('id', this._name)
  }
  changeRegion(event: any) {
    console.log(this.emplyeeForm.value.regionId);
    this.emplyeeForm.value.regionId
  }

  changeRole(event: any) {
    console.log(this.emplyeeForm.value.roleId)
    this.emplyeeForm.value.roleId
  }
  getRole() {
    this.dataService.rolesList().subscribe(data => {
      if (data.status == 200) {
        this.roleRecord = data.data

        console.log(this.roleRecord);
      }
      else if (data.status == 404) {
      
      }
      else if (data.status == 500) {
        this.toastr.error('Unable to process');
      }
    })
  }
  onSubmit() {
    if (this.id > 0) {
      this.update()
    }
    else {
      this.onSave();
    }
  }
  get f() { return this.emplyeeForm.controls; }
  set name(name: string) {
    this._name = name || '<id not found>';
    if (this._name == 'add') {
      this.status = false
      console.log(this.status)
      this.emplyeeForm.patchValue({
        name: "",
        userName: "",
        email: "",
        mobileNo: "",
        roleId: "",
        regionId: "",
        employeeCode: "",
        password: "",
        companyId: ""
      });
    }
    else {
      this.status = true
      this.id = name;
      if (this.id > 0) {
        this.buttonText = 'Update';
        this.headingText = "Update User"
        this.dataService.employeegGetProfile(this.id).subscribe(data => {
          if (data.status == 200) {
            this.emplyeeForm.patchValue({
              name: "" + data.data.name,
              userName: "" + data.data.userName,
              email: "" + data.data.email,
              mobileNo: "" + data.data.mobileNo,
              roleId: "" + data.data.roleId,
              regionId: "" + data.data.regionId,
              employeeCode: "" + data.data.employeeCode
            })
          }
        })

      }
    }



  }
  update() {
    this.dataService.updateEmployee(this.id, {
      name: this.emplyeeForm.value.name,
      userName: this.emplyeeForm.value.userName,
      password: this.emplyeeForm.value.password,
      email: this.emplyeeForm.value.email,
      mobileNo: this.emplyeeForm.value.mobileNo,
      employeeCode: this.emplyeeForm.value.employeeCode,
      roleId: 3,
      regionId: this.emplyeeForm.value.regionId,
    }).subscribe((data: any) => {
      if (data.status == 200) {
        this.myOutputVal.emit(this._name);
        this.toastr.success('Update Successfully');
        this.emplyeeForm.reset();
        this.submitted = false;
      }
      this.submitted = false;
      if (data.status == 204) {
        this.toastr.error('No Content Please fill all value');
      }
      if (data.status == 500) {
        this.toastr.error('Unable To Process');
      }

    })

  }
  onSave() {
    this.submitted = true;
    if (this.emplyeeForm.invalid) {
      console.table(this.emplyeeForm.value);
      return
    }
    if (this.emplyeeForm.valid) {
      console.table(this.emplyeeForm.value);
    }
    this.dataService.addEmployee({
      name: this.emplyeeForm.value.name,
      userName: this.emplyeeForm.value.userName,
      password: this.emplyeeForm.value.password,
      email: this.emplyeeForm.value.email,
      mobileNo: this.emplyeeForm.value.mobileNo,
      employeeCode: this.emplyeeForm.value.employeeCode,
      roleId: 3,
      regionId: this.emplyeeForm.value.regionId,
    }).subscribe(data => {
      if (data?.status == 200) {
        this.router.navigateByUrl('/user-managemnt');
        this.toastr.success('Employee Add Successfully');
        this.submitted = false;
        this.emplyeeForm.reset()
        this.myOutputVal.emit(this._name);
      }
      if (data?.status == 208) {
        this.toastr.error('User Name Already Exists');
      }
      if (data?.status == 209) {
        this.toastr.error('Mobile No already exits');
      }
      if (data?.status == 210) {
        this.toastr.error('Email Already Already Exists');
      }
      if (data?.status == 429) {
        this.toastr.error(' You have reached project add limit purchase new plan');
      }
      if (data?.status == 204) {
        this.toastr.error('Fiels Is Empty');
      }
      if (data?.status == 500) {
        this.toastr.success('Unable To Process');
      }
    })
  }

}
