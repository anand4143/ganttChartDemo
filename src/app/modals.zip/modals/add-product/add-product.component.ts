import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FormGroup, FormControl, FormArray, FormBuilder, Validators } from '@angular/forms'
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { DataService } from 'src/app/service/data.service';

@Component({
  selector: 'app-add-product',
  templateUrl: './add-product.component.html',
  styleUrls: ['./add-product.component.scss']
})
export class AddProductComponent implements OnInit {
  @Input('myInputVal') myInputVal: string;
  @Output('myOutputVal') myOutputVal = new EventEmitter();
  @Input() max: any;
  tomorrow = new Date();
  nextYear = new Date();
  productForm: FormGroup;
  regionRecord: any;
  submitted = false;
  status: boolean = false;
  empRecord: any;
  closeResult: string;
  modal = true;
  viewRecord: any;
  headingText = "Add Product"
  buttonText = "Create"
  constructor(private fb: FormBuilder, private router: Router, private dataService: DataService, private toastr: ToastrService) {
    this.productForm = this.fb.group({
      projectName: ['', [Validators.required]],
      startDate: ['', [Validators.required]],
      endDate: ['', [Validators.required]],
      regionId: ['', [Validators.required]],
    });
    this.dataService.getRegion().subscribe((data: any) => {
      if (data.status == 200) {

        this.regionRecord = data.data
      }
      if (data.status == 404) {
        // this.toastr.error('No Record Found!');
      }
      if (data.status == 500) {
        this.toastr.error('Unable To Process');
      }
    })
    this.dataService.stringSubject.subscribe(
      data => {
        this.myInputVal = data;
        console.log(this.myInputVal)
        if (this.myInputVal == 'add') {
          this.buttonText = "Create"
          this.headingText = "Add Product"

          this.productForm.reset();
          this.productForm.patchValue({
            projectName: "",
            responsivePerson: "",
            startDate: "",
            endDate: "",
            status: "",
            regionId: "",
          })
          this.submitted = false;
        }
        if (parseInt(this.myInputVal) > 0) {
          this.buttonText = "Update"
          this.headingText = "Update Product"
          this.getProjetc(this.myInputVal)
        }
      });
    this.tomorrow.setDate(this.tomorrow.getDate());
    this.nextYear.setDate(this.nextYear.getDate())

    this.productForm.reset()
  }
  getProjetc(myInputVal) {
    this.dataService.getProject(parseInt(myInputVal)).subscribe(data => {
      if (data.status == 200) {
        this.viewRecord = data.data;
        this.productForm.patchValue({
          projectName: "" + this.viewRecord.projectName,
          responsivePerson: "" + this.viewRecord.responsivePerson,
          startDate: "" + this.viewRecord.startDate,
          endDate: "" + this.viewRecord.endDate,
          status: "" + this.viewRecord.status,
          regionId: "" + this.viewRecord.regionId,
        })
      }
      if (data.status == 404) {
        // this.toastr.error("No Record Found");
      }
      if (data.status == 500) {
        this.toastr.error("Unable To ProcessF");
      }
    })
  }

  ngOnInit(): void {


  }
  onSubmit() {
    this.submitted = true;
    if (this.productForm.invalid) {
      console.table(this.productForm.value);
      return
    }
    if (this.productForm.valid) {
      console.table(this.productForm.value);
    }
    this.dataService.addProject({
      projectName: this.productForm.value.projectName,
      startDate: this.productForm.value.startDate,
      endDate: this.productForm.value.endDate,
      regionId: this.productForm.value.regionId,
      status: 1,
    }).subscribe((data: any) => {
      if (data?.status == 200) {
        this.router.navigateByUrl('/products');
        this.toastr.success('Project Add Successfully');
        this.myOutputVal.emit(this.myInputVal);
        this.productForm.reset()
        this.submitted = false;
      }
      if (data?.status == 208) {
        this.toastr.error('Project Name Already Exists');
      }
      if (data?.status == 429) {
        this.toastr.error(' You have reached project add limit purchase new plan');
      }
      if (data?.status == 204) {
        this.toastr.error('Fiels Is Empty');
      }
      if (data?.status == 500) {
        this.toastr.success('Unable To Process');
      }
    })
  }
  changeRegion(event: any) {
    console.log(this.productForm.value.regionId)
    this.productForm.value.regionId
  }
  get f() {
    return this.productForm.controls;
  }
  update() {
    this.submitted = true;
    if (this.productForm.invalid) {
      console.table(this.productForm.value);
      // return
    }
    if (this.productForm.valid) {
      console.table(this.productForm.value);
    }
    this.dataService.updateProject(this.myInputVal, {
      projectName: this.productForm.value.projectName,
      responsivePerson: this.productForm.value.responsivePerson,
      startDate: this.productForm.value.startDate,
      endDate: this.productForm.value.endDate,
      status: 1,
      regionId: this.productForm.value.regionId,
    }).subscribe((data: any) => {

      if (data?.status == 200) {
        this.submitted = false;
        this.productForm.patchValue({
          projectName: "",
          responsivePerson: "",
          startDate: "",
          endDate: "",
          status: "",
          regionId: "",
        })
        this.toastr.success('Project Update Successfully');
      }
      if (data?.status == 204) {
        this.toastr.error('Fiels Is Empty');
      }
      if (data?.status == 500) {
        this.toastr.success('Unable To Process');
      }
    })
  }

}
