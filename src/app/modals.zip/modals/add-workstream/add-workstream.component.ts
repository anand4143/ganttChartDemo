import { Component, Input, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { NgxSpinnerService } from 'ngx-spinner';
import { ToastrService } from 'ngx-toastr';
import { DataService } from 'src/app/service/data.service';

@Component({
  selector: 'app-add-workstream',
  templateUrl: './add-workstream.component.html',
  styleUrls: ['./add-workstream.component.scss']
})
export class AddWorkstreamComponent implements OnInit {
  _name: string; @Input('recordId')
  get name(): string { return this._name; }
  workSteamForm: FormGroup;
  submitted = false;
  headingText = "Add New Workstream";
  buttonText = "Create";
  status: boolean = false;
  id: any;
  display='none'; 
  constructor(private dataService: DataService, private fb: FormBuilder, private toaster: ToastrService, private spinner: NgxSpinnerService) {
    this.workSteamForm = this.fb.group({
      name: ['', Validators.required]
    })
    console.log(this._name)
  }

  ngOnInit(): void {

  }
  onSubmit() {
    if (this.id > 0) {
      this.update();
    }
    else {
      this.submitted = true;
      if (this.workSteamForm.invalid) {
        console.table(this.workSteamForm.value);
        return
      }
      if (this.workSteamForm.valid) {
        console.table(this.workSteamForm.value);
      }
      this.dataService.addWorkStream({
        name: this.workSteamForm.value.name
      }).subscribe(data => {
        if (data.status == 200) {
          this.submitted = false;
          this.workSteamForm.reset();
          this.toaster.success('Work Stream Add Successfully');
        }
        if (data.status == 204) {
          this.toaster.error('No Content');
        }
        if (data.status == 500) {
          this.toaster.error('Unable To Process');
        }
        if (data.status == 208) {
          this.toaster.error('Work Stream Aready Exits');
        }
      })
    }

  }
  get f() {
    return this.workSteamForm.controls;
  }
  set name(name: string) {
    console.log(name)
    this._name = name || '<id not found>';
    if (this._name == 'add') {
      this.headingText = "Add New Workstream";
      this.buttonText = "Create";
      this.status = false
      console.log(this.status)
      this.workSteamForm.patchValue({
        name: +"",
      });
      this.workSteamForm.reset();
    }
    else {
      this.status = true
      this.id = name;
      if (parseInt(this.id) > 0) {
        this.buttonText = 'Update';
        this.headingText = "Update User"
        this.dataService.getWorkStream(this.id).subscribe(data => {
          console.log(data)
          if (data.status == 200) {
            this.workSteamForm.patchValue({
              name: "" + data.data.name,
            })
          }
          if (data.status == 304) {
            this.toaster.error('Not Modify');
          }
          if (data.status == 500) {
            this.toaster.error('Unable To Process');
          }
        })
      }
    }
  }
  update() {
    this.submitted = true;
    if (this.workSteamForm.invalid) {
      console.table(this.workSteamForm.value);
      return
    }
    if (this.workSteamForm.valid) {
      console.table(this.workSteamForm.value);
    }
    this.dataService.updateWorkStream(this.id, {
      name: this.workSteamForm.value.name
    }).subscribe(data => {
      if (data.status == 200) {
        this.workSteamForm.patchValue({
          name: ""
        })
        this.submitted = false;
        this.workSteamForm.reset();
        this.toaster.success('Work Stream Update Successfully');
      }
      if (data.status == 204) {
        this.toaster.error('No Content');
      }
      if (data.status == 500) {
        this.toaster.error('Unable To Process');
      }
      if (data.status == 208) {
        this.toaster.error('Work Stream Aready Exits');
      }
    })
  }
  closeModalDialog(){
    this.display='modal'; //set none css after close dialog
   }
}
