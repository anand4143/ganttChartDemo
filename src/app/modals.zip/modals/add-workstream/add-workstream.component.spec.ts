import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddWorkstreamComponent } from './add-workstream.component';

describe('AddWorkstreamComponent', () => {
  let component: AddWorkstreamComponent;
  let fixture: ComponentFixture<AddWorkstreamComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddWorkstreamComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AddWorkstreamComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
