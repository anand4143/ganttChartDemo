import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { DataService } from 'src/app/service/data.service';

@Component({
  selector: 'app-add-tactics',
  templateUrl: './add-tactics.component.html',
  styleUrls: ['./add-tactics.component.scss']
})
export class AddTacticsComponent implements OnInit {
  @Input('myInputVal') myInputVal: string;
  @Output('myOutputVal') myOutputVal = new EventEmitter();
  tacticsForm: FormGroup;
  submitted = false;
  errMessage: any;
  employeeList: any;
  constructor(private router: Router, private toaster: ToastrService,
    private route: ActivatedRoute, private dataService: DataService, private fb: FormBuilder) {
    //tactic form
    this.tacticsForm = this.fb.group({
      name: ['', [Validators.required]],
      status: ['', [Validators.required]],
      startDate: ['', [Validators.required]],
      endDate: ['', [Validators.required]],
      description: ['', [Validators.required]],
      goalsId: [''],
      objecativeId: [''],
      strategyId: [''],
      assignBy: [''],
      assignTo: ['']
    })
    this.dataService.employeeList().subscribe(data => {
      if (data.status == 200) {
        this.employeeList = data.data
      }
      if (data.status == 404) {
        this.errMessage = "No Record Found!";
      }
      if (data.status == 500) {
        this.errMessage = "Unable To Process";
      }
    })
  }
  get f() {
    return this.tacticsForm.controls;
  }
  ngOnInit(): void {
  }
  //update tactics
  updateTactics(id: any) {
    this.submitted = false;
    if (this.tacticsForm.invalid) {
      console.table(this.tacticsForm.value);
      return
    }
    if (this.tacticsForm.valid) {
      console.table(this.tacticsForm.value);
    }
    this.dataService.updateTactics(id, {
      name: this.tacticsForm.value.name,
      status: this.tacticsForm.value.status,
      startDate: this.tacticsForm.value.startDate,
      endDate: this.tacticsForm.value.endDate,
      description: this.tacticsForm.value.description,
      goalsId: '1',
      objectiveId: '1',
      strategyId: '1',
      assignBy: "1",
    }).subscribe(data => {
      if (data.status == 200) {
        this.toaster.success('Update Successfully');
      }
      if (data.status == 404) {
        this.toaster.error('No Content');
      }
      if (data.status == 500) {
        this.toaster.error('Unable To Process');
      }
    })
  }
  //create Tactics
  onSubmit() {
    this.submitted = false;
    if (this.tacticsForm.invalid) {
      console.table(this.tacticsForm.value);
      return
    }
    if (this.tacticsForm.valid) {
      console.table(this.tacticsForm.value);
    }
    this.dataService.createTactics({
      name: this.tacticsForm.value.name,
      status: this.tacticsForm.value.status,
      startDate: this.tacticsForm.value.startDate,
      endDate: this.tacticsForm.value.endDate,
      description: this.tacticsForm.value.description,
      goalsId: '1',
      objectiveId: '1',
      strategyId: '1',
      assignBy: "1",
    }).subscribe(data => {
      if (data.status == 200) {
        this.myOutputVal.emit(this.myInputVal);
        this.submitted = false;
        this.tacticsForm.reset();
        this.toaster.success('Tactics Create Successfully');
      }
      if (data.status == 208) {
        this.toaster.error('Tactics Already Exits');
      }
      if (data.status == 404) {
        this.toaster.error('Req Body Is Empty');
      }
      if (data.status == 500) {
        this.toaster.error('Unable To Process');
      }
    })
  }

}
