import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddTacticsComponent } from './add-tactics.component';

describe('AddTacticsComponent', () => {
  let component: AddTacticsComponent;
  let fixture: ComponentFixture<AddTacticsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddTacticsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AddTacticsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
