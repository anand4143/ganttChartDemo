import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddStratgyComponent } from './add-stratgy.component';

describe('AddStratgyComponent', () => {
  let component: AddStratgyComponent;
  let fixture: ComponentFixture<AddStratgyComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddStratgyComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AddStratgyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
