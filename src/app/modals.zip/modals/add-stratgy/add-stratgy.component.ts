import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { NgxSpinnerService } from 'ngx-spinner';
import { ToastrService } from 'ngx-toastr';
import { DataService } from 'src/app/service/data.service';

@Component({
  selector: 'app-add-stratgy',
  templateUrl: './add-stratgy.component.html',
  styleUrls: ['./add-stratgy.component.scss']
})
export class AddStratgyComponent implements OnInit {
  @Input('myInputVal') myInputVal: string;
  @Output('myOutputVal') myOutputVal = new EventEmitter();
  strategyForm: FormGroup;
  submitted = false;
  errMessage: any;
  employeeList: any;
  constructor(private fb: FormBuilder, private toaster: ToastrService, private spinner: NgxSpinnerService, private dataService: DataService) {
    this.strategyForm = this.fb.group({
      name: ['', [Validators.required]],
      status: ['', [Validators.required]],
      startDate: ['', [Validators.required]],
      endDate: ['', [Validators.required]],
      description: [''],
      goalsId: [''],
      assignTo: [''],
      objectiveId: [''],
      assignBy: [''],
    })
    this.dataService.employeeList().subscribe(data => {
      if (data.status == 200) {
        this.employeeList = data.data
      }
      if (data.status == 404) {
        this.errMessage = "No Record Found!";
      }
      if (data.status == 500) {
        this.errMessage = "Unable To Process";
      }
    })
    this.dataService.stringSubject.subscribe(
      data => {
        this.myInputVal = data;
        console.log(this.myInputVal)
      });
  }

  ngOnInit(): void {
  }
  get f() {
    return this.strategyForm.controls;
  }
  onSubmit() {
    this.submitted = false;
    if (this.strategyForm.invalid) {
      console.table(this.strategyForm.value);
      return
    }
    if (this.strategyForm.valid) {
      console.table(this.strategyForm.value);
    }
    this.dataService.createStrategy({
      name: this.strategyForm.value.name,
      status: this.strategyForm.value.status,
      description: this.strategyForm.value.description,
      startDate: this.strategyForm.value.startDate,
      endDate: this.strategyForm.value.endDate,
      goalsId: this.myInputVal,
      objectiveId: this.myInputVal,
      assignBy: this.myInputVal,
    }).subscribe(data => {
      if (data.status == 200) {
        this.toaster.success('Strategy Create Successfully');
        this.myOutputVal.emit(this.myInputVal);
        this.strategyForm.reset();
        this.submitted = false;
      }
      if (data.status == 208) {
        this.toaster.error('Strategy Already Exits');
      }
      if (data.status == 404) {
        this.toaster.error('Req Body Is Empty');
      }
      if (data.status == 500) {
        this.toaster.error('Unable To Process');
      }
    })
  }
  updateStrategy(id: any) {
    this.dataService.updateStrategy(id, {
      name: this.strategyForm.value.name,
      status: this.strategyForm.value.status,
      description: this.strategyForm.value.description,
      startDate: this.strategyForm.value.startDate,
      endDate: this.strategyForm.value.endDate,
      goalsId: this.strategyForm.value.goalsId,
      objecativeId: this.strategyForm.value.objecativeId,
      assignBy: this.strategyForm.value.assignBy,
    }).subscribe(data => {
      if (data.status == 200) {
        this.toaster.success('Update Successfully');
      }
      if (data.status == 404) {
        this.toaster.error('No Content');
      }
      if (data.status == 500) {
        this.toaster.error('Unable To Process');
      }
    })
  }
}
